//
//  view3.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/30/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "view3.h"

@interface view3 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *hours;
    NSString *tmp;
    NSInteger selectedRowh;
    NSInteger selectedRowmin;
    
    }
@property (weak, nonatomic) IBOutlet UITextField *q9t;
@property (strong, nonatomic) IBOutlet UIButton *q10b1;
@property (strong, nonatomic) IBOutlet UIButton *q10b2;
@property (strong, nonatomic) IBOutlet UIButton *q10b3;
@property (weak, nonatomic) IBOutlet UIPickerView *q10ph;
@property (weak, nonatomic) IBOutlet UIPickerView *q10pmin;

@end

@implementation view3

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
       // _q10b1.titleLabel.text=@"yyyyyy";
        
    }
    return self;
}

- (void)viewDidLoad
{
   /* _q10ph.dataSource=self;
    _q10pmin.dataSource=self;
    _q10ph.delegate=self;
    _q10pmin.delegate=self;
    */
    hours = [NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26", @"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
    [super viewDidLoad];
    
	// Do any additional setup after loading the view.
    
    
}

- (IBAction)q10b1_press:(id)sender {
    
    //_q10b1.titleLabel.text=@"Selecting";
    selectedRowh = [ _q10ph  selectedRowInComponent:0];
    selectedRowmin=[_q10pmin selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];

    [_q10b1 setTitle:tmp forState:UIControlStateNormal];

  //  _q10b1.titleLabel.text=NSLocalizedString(tmp,nil);
    NSLog(@"%@",tmp);
    //[_q10b1 reloadInputViews];
    
 
}
- (IBAction)q10b2_press:(id)sender {
    
    //_q10b1.titleLabel.text=@"Selecting";
    selectedRowh = [ _q10ph  selectedRowInComponent:0 ];
    selectedRowmin=[_q10pmin selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [_q10b2 setTitle:tmp forState:UIControlStateNormal];
    
    
}
- (IBAction)q10b3_press:(id)sender {
    
    //_q10b1.titleLabel.text=@"Selecting";
    selectedRowh = [ _q10ph  selectedRowInComponent:0 ];
    selectedRowmin=[_q10pmin selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [_q10b3 setTitle:tmp forState:UIControlStateNormal];
}





-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
        return [hours count];
    
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    
        return [hours objectAtIndex:row];
    
}

- (IBAction)Proceed:(id)sender {
    NSString *documentsDire = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSString *plistPath = [documentsDire stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    
    
    [plistDict setObject:_q9t.text atIndexedSubscript:12];
    
    [plistDict setObject:_q10b1.titleLabel.text atIndexedSubscript:13];
    [plistDict setObject:_q10b2.titleLabel.text atIndexedSubscript:14];
    [plistDict setObject:_q10b3.titleLabel.text atIndexedSubscript:15];
    //[plistDict setObject:_q10b3.titleLabel.text atIndexedSubscript:1:@"TRANSIT"];
    
    
    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
    
    
    
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)viewDidUnload {
    [self setQ10b1:nil];
    [self setQ10b2:nil];
    [self setQ10b3:nil];
    [self setQ10ph:nil];
    [self setQ10pmin:nil];
    [super viewDidUnload];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
