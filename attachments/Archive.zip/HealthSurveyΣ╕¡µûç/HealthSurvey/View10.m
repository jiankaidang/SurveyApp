//
//  view4.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/30/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "View10.h"

@interface View10 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *hours;
    NSString *tmp;
    NSInteger selectedRowh;
    NSInteger selectedRowmin;
    
}
@property (strong, nonatomic) IBOutlet UIButton *q11a4;
@property (strong, nonatomic) IBOutlet UIButton *q11b4;
@property (strong, nonatomic) IBOutlet UIButton *q11a5;
@property (strong, nonatomic) IBOutlet UIButton *q11b5;
@property (strong, nonatomic) IBOutlet UIButton *q11a6;
@property (strong, nonatomic) IBOutlet UIButton *q11b6;

@property (strong, nonatomic) IBOutlet UIButton *q114b1;
@property (strong, nonatomic) IBOutlet UIButton *q115b1;
@property (strong, nonatomic) IBOutlet UIButton *q116b1;

@property (strong, nonatomic) IBOutlet UIButton *q114b2;
@property (strong, nonatomic) IBOutlet UIButton *q115b2;
@property (strong, nonatomic) IBOutlet UIButton *q116b2;
@property (strong, nonatomic) IBOutlet UIPickerView *q11h;
@property (strong, nonatomic) IBOutlet UIPickerView *q11min;

@end

@implementation View10

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    hours = [NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26", @"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
- (IBAction)q10a4_press:(id)sender {
    _q11a4.selected=true;
    [_q11a4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q11b4.selected=false;
    [_q11b4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q114b1.hidden=false;
    _q114b2.hidden=false;
}
- (IBAction)q10b4_press:(id)sender {
    _q11b4.selected=true;
    [_q11b4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q11a4.selected=false;
    [_q11a4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q114b1.hidden=true;
    _q114b2.hidden=true;
}
- (IBAction)q10a5_press:(id)sender {
    _q11a5.selected=true;
    [_q11a5 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q11b5.selected=false;
    [_q11b5 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q115b1.hidden=false;
    _q115b2.hidden=false;
}
- (IBAction)q10b5_press:(id)sender {
    _q11b5.selected=true;
    [_q11b5 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q11a5.selected=false;
    [_q11a5 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q115b1.hidden=true;
    _q115b2.hidden=true;
}- (IBAction)q10a6_press:(id)sender {
    _q11a6.selected=true;
    [_q11a6 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q11b6.selected=false;
    [_q11b6 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q116b1.hidden=false;
    _q116b2.hidden=false;
}
- (IBAction)q10b6_press:(id)sender {
    _q11b6.selected=true;
    [_q11b6 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q11a6.selected=false;
    [_q11a6 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q116b1.hidden=true;
    _q116b2.hidden=true;
}


- (IBAction)q111b1_press:(id)sender {
    
    selectedRowh = [ _q11h  selectedRowInComponent:0];
    selectedRowmin=[_q11min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [sender setTitle:tmp forState:UIControlStateNormal];
    
    
}




-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return [hours count];
    
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    
    return [hours objectAtIndex:row];
    
}

- (IBAction)Proceed:(id)sender {
    NSString *documentsDire = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSString *plistPath = [documentsDire stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    
    
    // [plistDict setObject:_q9t.text atIndexedSubscript:1:@"WAGE"];
    
   
    [plistDict setObject:_q114b1.titleLabel.text atIndexedSubscript:26];
    [plistDict setObject:_q115b1.titleLabel.text atIndexedSubscript:28];
    [plistDict setObject:_q116b1.titleLabel.text atIndexedSubscript:30];
    
    [plistDict setObject:_q114b2.titleLabel.text atIndexedSubscript:27];
    [plistDict setObject:_q115b2.titleLabel.text atIndexedSubscript:29];
    [plistDict setObject:_q116b2.titleLabel.text atIndexedSubscript:31];
    
    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
    
    
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
       [self setQ11b4:nil];
    [self setQ11b4:nil];
       [self setQ114b1:nil];
    [self setQ11h:nil];
    [self setQ11min:nil];
    [super viewDidUnload];
}
@end
