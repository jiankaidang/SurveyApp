//
//  view4.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/30/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "View6.h"

@interface View6 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *hours;
    NSString *tmp;
    NSInteger selectedRowh;
    NSInteger selectedRowmin;
    
}
@property (strong, nonatomic) IBOutlet UIButton *q12a1;
@property (strong, nonatomic) IBOutlet UIButton *q12b1;
@property (strong, nonatomic) IBOutlet UIButton *q12a2;
@property (strong, nonatomic) IBOutlet UIButton *q12b2;
@property (strong, nonatomic) IBOutlet UIButton *q12a3;
@property (strong, nonatomic) IBOutlet UIButton *q12b3;

@property (strong, nonatomic) IBOutlet UIButton *q121b1;
@property (strong, nonatomic) IBOutlet UIButton *q122b1;
@property (strong, nonatomic) IBOutlet UIButton *q123b1;

@property (strong, nonatomic) IBOutlet UIButton *q121b2;
@property (strong, nonatomic) IBOutlet UIButton *q122b2;
@property (strong, nonatomic) IBOutlet UIButton *q123b2;

@property (strong, nonatomic) IBOutlet UIPickerView *q12h;
@property (strong, nonatomic) IBOutlet UIPickerView *q12min;

@end

@implementation View6

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    hours = [NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"12",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26", @"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}




- (IBAction)q10a1_press:(id)sender {
    _q12a1.selected=true;
    [_q12a1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12b1.selected=false;
    [_q12b1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q121b1.hidden=false;
    _q121b2.hidden=false;
    
}
- (IBAction)q10b1_press:(id)sender {
    _q12b1.selected=true;
    [_q12b1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12a1.selected=false;
    [_q12a1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q121b1.hidden=true;
    _q121b2.hidden=true;
    
}
- (IBAction)q10a2_press:(id)sender {
    _q12a2.selected=true;
    [_q12a2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12b2.selected=false;
    [_q12b2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q122b1.hidden=false;
    _q122b2.hidden=false;
    
}
- (IBAction)q10b2_press:(id)sender {
    _q12b2.selected=true;
    [_q12b2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12a2.selected=false;
    [_q12a2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q122b1.hidden=true;
    _q122b2.hidden=true;
}
- (IBAction)q10a3_press:(id)sender {
    _q12a3.selected=true;
    [_q12a3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12b3.selected=false;
    [_q12b3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q123b1.hidden=false;
    _q123b2.hidden=false;
}
- (IBAction)q10b3_press:(id)sender {
    _q12b3.selected=true;
    [_q12b3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12a3.selected=false;
    [_q12a3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q123b1.hidden=true;
    _q123b2.hidden=true;
}

- (IBAction)q126b2_press:(id)sender {
    
    selectedRowh = [ _q12h  selectedRowInComponent:0];
    selectedRowmin=[_q12min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [sender setTitle:tmp forState:UIControlStateNormal];
    
    
}



-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return [hours count];
    
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    
    return [hours objectAtIndex:row];
    
}

- (IBAction)Proceed:(id)sender {
    NSString *documentsDire = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSString *plistPath = [documentsDire stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    
    
    // [plistDict setObject:_q9t.text atIndexedSubscript:1:@"WAGE"];
    
    [plistDict setObject:_q121b1.titleLabel.text atIndexedSubscript:32];
    [plistDict setObject:_q122b1.titleLabel.text atIndexedSubscript:34];
    [plistDict setObject:_q123b1.titleLabel.text atIndexedSubscript:36];
  
    [plistDict setObject:_q121b2.titleLabel.text atIndexedSubscript:33];
    [plistDict setObject:_q122b2.titleLabel.text atIndexedSubscript:35];
    [plistDict setObject:_q123b2.titleLabel.text atIndexedSubscript:37];
   
    
    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
    
    
    
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setQ12b1:nil];
    [self setQ12b1:nil];
    [self setQ12a2:nil];
    [self setQ12b2:nil];
    [self setQ12a3:nil];
    [self setQ12b3:nil];
   
    [self setQ121b1:nil];
    [self setQ122b1:nil];
    [self setQ123b1:nil];
    
    [self setQ12h:nil];
    [self setQ12min:nil];
    [super viewDidUnload];
}
@end
