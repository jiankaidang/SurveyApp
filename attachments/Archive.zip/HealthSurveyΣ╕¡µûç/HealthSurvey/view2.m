//
//  view2.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/23/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "view2.h"

@interface view2 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *q7parray;
    NSArray *q8parray;
}

@property (strong, nonatomic) IBOutlet UIButton *q6a;
@property (strong, nonatomic) IBOutlet UIButton *q6b;

@property (strong, nonatomic) IBOutlet UIButton *q7b;
@property (weak, nonatomic) IBOutlet UIPickerView *q7p;
@property (weak, nonatomic) IBOutlet UIPickerView *q8p;
@property (strong, nonatomic) IBOutlet UIButton *q8b;

@property (strong, nonatomic) IBOutlet UIButton *q8down;
@property (strong, nonatomic) IBOutlet UILabel *q8q;

@end

@implementation view2

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (IBAction)press:(id)sender {
       _q7p.hidden=false;

}
- (IBAction)q8p_press:(id)sender {
    _q8p.hidden=false;
    
}
- (void)viewDidLoad
{
    q7parray = [NSArray arrayWithObjects:NSLocalizedString(@"00 没上过学 (跳到问题 9)", nil),NSLocalizedString(@"11 1 年小学 (跳到问题 9)", nil),NSLocalizedString(@"12 2 年小学 (跳到问题 9)", nil),NSLocalizedString(@"13 3 年小学 (跳到问题 9)", nil),NSLocalizedString(@"14 4 年小学 (跳到问题 9)", nil),NSLocalizedString(@"15 5 年小学", nil),NSLocalizedString(@"16 6 年小学", nil),NSLocalizedString(@"21 1年初中", nil),NSLocalizedString(@"22 2年初中", nil),NSLocalizedString(@"23 3年初中", nil),NSLocalizedString(@"24 1年高中", nil),NSLocalizedString(@"25 2年高中", nil),NSLocalizedString(@"26 3年高中", nil),NSLocalizedString(@"27 1年中等技术学校", nil),NSLocalizedString(@"28 2年中等技术学校", nil),NSLocalizedString(@"29 3年中等技术学校", nil),NSLocalizedString(@"31 1年大学", nil),NSLocalizedString(@"32 2年大学", nil),NSLocalizedString(@"33 3年大学", nil),NSLocalizedString(@"34 4年大学", nil),NSLocalizedString(@"35 5年大学", nil),NSLocalizedString(@"36 6年大学或更多", nil),NSLocalizedString(@"9 不知道", nil),nil];
    q8parray=[NSArray arrayWithObjects:@"1 小学毕业", @"2 初中毕业",@"3 高中毕业",@"4 中等技术学校、职业学校毕业",@"5 大专或大学毕业",@"6 硕士及以上",@"9 不知道",nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
}
- (IBAction)q6a_press:(id)sender {
    _q6a.selected=true;
    [_q6a setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q6b.selected=false;
    [_q6b setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    
}

- (IBAction)q6b_press:(id)sender {
    _q6b.selected=true;
    [_q6b setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q6a.selected=false;
    [_q6a setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    
}


-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (pickerView==self.q7p)
    {
        return [q7parray count];
    }
    else
    {
        return [q8parray count];
    }
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    if (pickerView==self.q7p)
    {
        return [q7parray objectAtIndex:row];
    }
    else
    {
       // NSLog(@"sucess into q8p");
        return [q8parray objectAtIndex:row];
    }
}
/*
 -(void)textFieldDidEndEditing:(UITextField *)textField{
 NSInteger row = [_q5p selectedRowInComponent:0];
 self.q5b.titleLabel.text = [q5parray objectAtIndex:row];
 }
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    //NSInteger row = [_q5p selectedRowInComponent:0];
    if (pickerView==self.q7p)
    {
        _q7b.titleLabel.text=[q7parray objectAtIndex:row];
        _q7p.hidden=true;
        [_q7b reloadInputViews];
        if((row>=0)&&(row<5))
        {
            _q8b.hidden=true;
            _q8down.hidden=true;
            _q8q.hidden=true;
            [_q8b reloadInputViews];
            [_q8down reloadInputViews];
            [_q8q reloadInputViews];
          //  NSLog(@"wow");
        }
        else
        {
            _q8b.hidden=false ;
            _q8down.hidden=false;
            [_q8b reloadInputViews];
            [_q8down reloadInputViews];
            _q8q.hidden=false;
            [_q8q reloadInputViews];
        }
    }
    else if (pickerView==self.q8p)
    {
        _q8b.titleLabel.text=[q8parray objectAtIndex:row];
        _q8p.hidden=true;
        [_q8b reloadInputViews];
    }
    
}
- (void)viewDidUnload
{
    [self setQ6a:nil];
    [self setQ6b:nil];
    [self setQ7b:nil];
    [self setQ7p:nil];
    [self setQ8p:nil];
    [self setQ8b:nil];

    [self setQ8down:nil];
    [self setQ8q:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
- (IBAction)Proceed:(id)sender {
    NSString *documentsDire = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSString *plistPath = [documentsDire stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];

    if(_q6a.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:9];
    }
    else if(_q6b.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:9];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:9];
    }
    [plistDict setObject:[_q7b.titleLabel.text substringWithRange:NSMakeRange(0,2)] atIndexedSubscript:10];
    
    [plistDict setObject:[_q8b.titleLabel.text substringWithRange:NSMakeRange(0,2)] atIndexedSubscript:11];

    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
