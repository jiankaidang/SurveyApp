//
//  View8.m
//  HealthSurvey
//
//  Created by Dax Dawson on 10/1/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "View8.h"
#import "NetworkManager.h" 

@interface View8 ()
@property (strong, nonatomic) IBOutlet UIButton *q15a1;
@property (strong, nonatomic) IBOutlet UIButton *q15b1;
@property (strong, nonatomic) IBOutlet UIButton *q15a2;
@property (strong, nonatomic) IBOutlet UIButton *q15b2;
@property (strong, nonatomic) IBOutlet UIButton *q15a3;
@property (strong, nonatomic) IBOutlet UIButton *q15b3;
@property (strong, nonatomic) IBOutlet UIButton *q15a4;
@property (strong, nonatomic) IBOutlet UIButton *q15b4;
@property (strong, nonatomic) IBOutlet UIButton *q15a5;
@property (strong, nonatomic) IBOutlet UIButton *q15b5;
@property (strong, nonatomic) IBOutlet UITextField *q16t1;
@property (strong, nonatomic) IBOutlet UITextField *q16t2;

@end

@implementation View8

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
- (IBAction)q15a1_press:(id)sender {
    _q15a1.selected=true;
    [_q15a1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15b1.selected=false;
    [_q15b1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
       
}
- (IBAction)q15b1_press:(id)sender {
    _q15b1.selected=true;
    [_q15b1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15a1.selected=false;
    [_q15a1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
       
}
- (IBAction)q15a2_press:(id)sender {
    _q15a2.selected=true;
    [_q15a2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15b2.selected=false;
    [_q15b2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
       
}
- (IBAction)q15b2_press:(id)sender {
    _q15b2.selected=true;
    [_q15b2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15a2.selected=false;
    [_q15a2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
   
}

- (IBAction)q15a3_press:(id)sender {
    _q15a3.selected=true;
    [_q15a3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15b3.selected=false;
    [_q15b3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];

    
}
- (IBAction)q15b3_press:(id)sender {
    _q15b3.selected=true;
    [_q15b3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15a3.selected=false;
    [_q15a3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
  
    
}
- (IBAction)q15a4_press:(id)sender {
    _q15a4.selected=true;
    [_q15a4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15b4.selected=false;
    [_q15b4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];

    
}
- (IBAction)q15b4_press:(id)sender {
    _q15b4.selected=true;
    [_q15b4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15a4.selected=false;
    [_q15a4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
  
}
- (IBAction)q15a5_press:(id)sender {
    _q15a5.selected=true;
    [_q15a5 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15b5.selected=false;
    [_q15b5 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];

    
}
- (IBAction)q15b5_press:(id)sender {
    _q15b5.selected=true;
    [_q15b5 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q15a5.selected=false;
    [_q15a5 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];

}

- (IBAction)Save:(id)sender {
    NSString *documentsDire = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSString *plistPath = [documentsDire stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
  //  NSString *plistPathAll=[[NSBundle mainBundle]pathForResource:@"storeddata" ofType:@"plist"];
   // NSMutableArray *plistDictAll=[[NSMutableArray alloc] initWithContentsOfFile:plistPathAll];
    
    // [plistDict setObject:_q9t.text atIndexedSubscript:1:@"WAGE"]
    if(_q15a1.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:51];
    }
    else if(_q15b1.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:51];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:51];
    }
    if(_q15a2.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:52];
    }
    else if(_q15b2.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:52];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:52];
    }
    if(_q15a3.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:53];
    }
    else if(_q15b3.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:53];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:53];
    }
    if(_q15a4.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:54];
    }
    else if(_q15b4.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:54];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:54];
    }
    if(_q15a5.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:55];
    }
    else if(_q15b5.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:55];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:55];
    }
    [plistDict setObject:_q16t1.text atIndexedSubscript:56];
    [plistDict setObject:_q16t2.text atIndexedSubscript:57];
    
    
    [plistDict writeToFile:plistPath atomically:YES];
    
   // [plistDictAll setObject:plistDict atIndexedSubscript:[plistDictAll count]];
  //  [plistDictAll writeToFile:plistPathAll atomically:YES];
   // NSLog(@"%@",plistDictAll);
    
    /*
    
    
    NSString *content;// = @"content here";
    for (NSInteger a=0; a<60; a=a+1) {
        [plistDict addObject:@"0"];
    }
    for (NSInteger a=0; a<58; a=a+1) {
        [content stringByAppendingString:[plistDict objectAtIndex:a]];
    }
    NSData *fileContents = [content dataUsingEncoding:NSUTF8StringEncoding];
    [[NSFileManager defaultManager] createFileAtPath:@"/my/path/to/file.csv"
                                            contents:fileContents
                                          attributes:nil];
    
    */
    
    for(NSInteger i=0;i<58;i++)
    {
        NSString *element = [plistDict objectAtIndex:i];//)
        //{
        if (([element isEqualToString:@"设置时间"])||([element isEqualToString:@"            选择            "]))
        {
            [plistDict setObject:@"" atIndexedSubscript:i];
            
        }
        NSLog(@"%i",i);
    }
    NSLog(@"%i",[plistDict count]);
    
    
   // NSString *filePath=[[NSBundle mainBundle]pathForResource:@"fileArray" ofType:@"csv"];
  //  NSString *filePath=[[NetworkManager sharedInstance] resultsFilePath];
    
    // Create file manager
   // NSFileManager *fileMgr = [NSFileManager defaultManager];
    
    //NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    // NSString *documentsDirectory = [paths objectAtIndex:0];
    //NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"fileArray.csv"];
    
    NSString *documentsDirectory = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSError *error;
    NSString *numberPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"number.txt"]];
    
    NSInteger bb=[[[NSString alloc] initWithContentsOfFile:numberPath encoding:NSUTF8StringEncoding error:&error] intValue];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"fileArray%i.csv",bb]];
    //[[NSFileManager defaultManager] createFileAtPath:filePathcontents:nil attributes:nil];
    
    
    
    NSMutableString *printString = [[NSMutableString alloc] initWithContentsOfFile:filePath];
    
    
    NSLog(@"%@",printString);
    [printString appendString:@"\n "];
    
    for(NSInteger i=0;i<59;i++)
    {
        //for (
        NSString *element = [plistDict objectAtIndex:i];//)
        //{
            [printString appendString:[NSString stringWithFormat:@"%@",element] ];
        //}
        [printString appendString:@","];
    }
    //CREATE FILE
    
   // NSError *error;
    
    NSLog(@"%@",filePath);
    NSLog(@"string to write:%@",printString);
    // Write to the file
    [printString writeToFile:filePath atomically:YES
                    encoding:NSUTF8StringEncoding error:&error];

}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setQ15a1:nil];
    [self setQ15b1:nil];
    [self setQ15a2:nil];
    [self setQ15b2:nil];
    [self setQ15a3:nil];
    [self setQ15b3:nil];
    [self setQ15a4:nil];
    [self setQ15b4:nil];
    [self setQ15a5:nil];
    [self setQ15b5:nil];
    [self setQ16t1:nil];
    [self setQ16t2:nil];
    [super viewDidUnload];
}
@end
