//
//  ViewController.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/23/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "ViewController.h"
@interface ViewController()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *q5parray;
}




@property (strong, nonatomic) IBOutlet UITextField *q1t1;
@property (strong, nonatomic) IBOutlet UITextField *q1t2;
@property (strong, nonatomic) IBOutlet UITextField *q1t3;

@property (strong, nonatomic) IBOutlet UITextField *q3t;
@property (strong, nonatomic) IBOutlet UIButton *q5b;

@property (weak, nonatomic) IBOutlet UIPickerView *q5p;
//@property (strong, nonatomic) IBOutlet UITableView *q5t;
//@property NSNumber *counts;
@end

@implementation ViewController
//@synthesize q5p = _q5p;


@synthesize q1t1 = _q1t1;
@synthesize q1t2 = _q1t2;
@synthesize q1t3 = _q1t3;
@synthesize q3t = _q3t;
@synthesize q5b = _q5b;
@synthesize q5p = _q5p;
@synthesize q2a=_q2a;
@synthesize q2b=_q2b;
@synthesize q4a=_q4a;
@synthesize q4b=_q4b;

- (void)viewDidLoad
{
    q5parray = [NSArray arrayWithObjects:NSLocalizedString(@"1 never married", nil),NSLocalizedString(@"2 married", nil),NSLocalizedString(@"3 divorced", nil),NSLocalizedString(@"4 separated", nil),NSLocalizedString(@"5 widowed", nil),NSLocalizedString(@"9 unknown", nil),nil];//@"",@"",@"",@"",@"",@"",nil];
    
    //NSLog(@"%@",q5parray);

    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)q2a_press:(id)sender {
    _q2a.selected=true;
    [_q2a setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q2b.selected=false;
    [_q2b setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];

}
- (IBAction)q2b_press:(id)sender {
    _q2b.selected=true;
    [_q2b setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q2a.selected=false;
    [_q2a setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    
}

- (IBAction)q4a_press:(id)sender {
    _q4a.selected=true;
    [_q4a setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q4b.selected=false;
    [_q4b setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    
}

- (IBAction)q4b_press:(id)sender {
    _q4b.selected=true;
    [_q4b setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q4a.selected=false;
    [_q4a setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    
}


-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    //NSLog(@"%d",[q5parray count]);
    return [q5parray count];
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [q5parray objectAtIndex:row];
}
/*
-(void)textFieldDidEndEditing:(UITextField *)textField{
    NSInteger row = [_q5p selectedRowInComponent:0];
    self.q5b.titleLabel.text = [q5parray objectAtIndex:row];
}
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    //NSInteger row = [_q5p selectedRowInComponent:0];
    
    _q5b.titleLabel.text=[q5parray objectAtIndex:row];
    _q5p.hidden=true;
}



- (IBAction)Proceed:(id)sender {
    NSString *documentsDirectory = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSError *error;
    
    NSString *plistPath=[documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    NSLog(@"%@",plistDict);
    
    
    [plistDict setObject:_q1t1.text atIndexedSubscript:2];
    [plistDict setObject:_q1t2.text atIndexedSubscript:3];
    [plistDict setObject:_q1t3.text atIndexedSubscript:4];
    if(_q2a.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:5];
    }
    else if(_q2b.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:5];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:5];
    }
    [plistDict setObject:_q3t.text atIndexedSubscript:6];
    if(_q4a.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:7];
    }
    else if(_q4b.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:7];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:7];
    }
    [plistDict setObject:[_q5b.titleLabel.text substringWithRange:NSMakeRange(0,2)] atIndexedSubscript:8];
    [plistDict writeToFile:plistPath atomically:YES];
    
}

- (void)viewDidUnload
{
    [self setQ2a:nil];
    [self setQ2b:nil];
    [self setQ4a:nil];
    [self setQ4b:nil];
    [self setQ1t1:nil];
    [self setQ1t2:nil];
    [self setQ1t3:nil];
    [self setQ3t:nil];
   // [self setQ5t:nil];
   // [self setTv:nil];
    [self setQ5p:nil];
    [self setQ5b:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}



- (IBAction)q5b_press:(id)sender {
 //   _q5t.hidden=false;
    // [_q5t reloadData];
    // [_q5t s]
    _q5p.hidden=false;
}


@end






















/*
 
 - (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
 NSLog(@"Im out.");
 return [self->q5parray count];
 }
 
 
 - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
 {
 static NSString *simpleTableIdentifier = @"answersCell";
 UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
 if (cell == nil) {
 cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
 reuseIdentifier:simpleTableIdentifier];
 }
 NSUInteger row = [indexPath row];
 cell.textLabel.text = [self->q5parray objectAtIndex:row];
 // cell.textLabel.text = [self.answers objectAtIndex:indexPath.row];
 NSLog( @"Im in.");
 return cell;
 
 }
 */

