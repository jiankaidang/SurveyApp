//
//  view4.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/30/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "view4.h"

@interface view4 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *hours;
    NSString *tmp;
    NSInteger selectedRowh;
    NSInteger selectedRowmin;
    
}
@property (strong, nonatomic) IBOutlet UIButton *q10a1;
@property (strong, nonatomic) IBOutlet UIButton *q10b1;
@property (strong, nonatomic) IBOutlet UIButton *q10a2;
@property (strong, nonatomic) IBOutlet UIButton *q10b2;
@property (strong, nonatomic) IBOutlet UIButton *q10a3;
@property (strong, nonatomic) IBOutlet UIButton *q10b3;
@property (strong, nonatomic) IBOutlet UIButton *q10a4;
@property (strong, nonatomic) IBOutlet UIButton *q10b4;
@property (strong, nonatomic) IBOutlet UIButton *q101b;
@property (strong, nonatomic) IBOutlet UIButton *q102b;
@property (strong, nonatomic) IBOutlet UIButton *q103b;
@property (strong, nonatomic) IBOutlet UIButton *q104b;
@property (strong, nonatomic) IBOutlet UIPickerView *q10h;
@property (strong, nonatomic) IBOutlet UIPickerView *q10min;

@end

@implementation view4

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    hours = [NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26", @"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}




- (IBAction)q10a1_press:(id)sender {
    _q10a1.selected=true;
    [_q10a1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10b1.selected=false;
    [_q10b1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q101b.hidden=false;
    
}
- (IBAction)q10b1_press:(id)sender {
    _q10b1.selected=true;
    [_q10b1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10a1.selected=false;
    [_q10a1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q101b.hidden=true;
    
}
- (IBAction)q10a2_press:(id)sender {
    _q10a2.selected=true;
    [_q10a2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10b2.selected=false;
    [_q10b2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q102b.hidden=false;
    
}
- (IBAction)q10b2_press:(id)sender {
    _q10b2.selected=true;
    [_q10b2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10a2.selected=false;
    [_q10a2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q102b.hidden=true;
}
- (IBAction)q10a3_press:(id)sender {
    _q10a3.selected=true;
    [_q10a3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10b3.selected=false;
    [_q10b3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q103b.hidden=false;
}
- (IBAction)q10b3_press:(id)sender {
    _q10b3.selected=true;
    [_q10b3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10a3.selected=false;
    [_q10a3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q103b.hidden=true;
}
- (IBAction)q10a4_press:(id)sender {
    _q10a4.selected=true;
    [_q10a4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10b4.selected=false;
    [_q10b4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q104b.hidden=false;
}
- (IBAction)q10b4_press:(id)sender {
    _q10b4.selected=true;
    [_q10b4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q10a4.selected=false;
    [_q10a4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q104b.hidden=true;
}



- (IBAction)q101b_press:(id)sender {
    
    //_q10b1.titleLabel.text=@"Selecting";
    selectedRowh = [ _q10h  selectedRowInComponent:0];
    selectedRowmin=[_q10min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [_q101b setTitle:tmp forState:UIControlStateNormal];
    
    //  _q10b1.titleLabel.text=NSLocalizedString(tmp,nil);
    NSLog(@"%@",tmp);
    //[_q10b1 reloadInputViews];
    
    
}
- (IBAction)q102b_press:(id)sender {
    
    //_q10b1.titleLabel.text=@"Selecting";
    selectedRowh = [ _q10h  selectedRowInComponent:0 ];
    selectedRowmin=[_q10min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [_q102b setTitle:tmp forState:UIControlStateNormal];
    
    
}
- (IBAction)q103b_press:(id)sender {
    
    //_q10b1.titleLabel.text=@"Selecting";
    selectedRowh = [ _q10h  selectedRowInComponent:0 ];
    selectedRowmin=[_q10min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [_q103b setTitle:tmp forState:UIControlStateNormal];
}

- (IBAction)q104b_press:(id)sender {
    
    //_q10b1.titleLabel.text=@"Selecting";
    selectedRowh = [ _q10h  selectedRowInComponent:0 ];
    selectedRowmin=[_q10min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [_q104b setTitle:tmp forState:UIControlStateNormal];
}




-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return [hours count];
    
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    
    return [hours objectAtIndex:row];
    
}

- (IBAction)Proceed:(id)sender {
    NSString *documentsDirectory = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSError *error;
    
    NSString *plistPath=[documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    
    
   // [plistDict setObject:_q9t.text atIndexedSubscript:1:@"WAGE"];
    
    [plistDict setObject:_q101b.titleLabel.text atIndexedSubscript:16];
    [plistDict setObject:_q102b.titleLabel.text atIndexedSubscript:17];
    [plistDict setObject:_q103b.titleLabel.text atIndexedSubscript:18];
    [plistDict setObject:_q104b.titleLabel.text atIndexedSubscript:19];
    
    
    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
    
    
    
    
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setQ10b1:nil];
    [self setQ10b1:nil];
    [self setQ10a2:nil];
    [self setQ10b2:nil];
    [self setQ10a3:nil];
    [self setQ10b3:nil];
    [self setQ10b4:nil];
    [self setQ10b4:nil];
    [self setQ10b1:nil];
    [self setQ10b2:nil];
    [self setQ103b:nil];
    [self setQ104b:nil];
    [self setQ10h:nil];
    [self setQ10min:nil];
    [super viewDidUnload];
}
@end
