//
//  view2.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/23/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "view2.h"

@interface view2 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *q7parray;
    NSArray *q8parray;
}

@property (strong, nonatomic) IBOutlet UIButton *q6a;
@property (strong, nonatomic) IBOutlet UIButton *q6b;

@property (strong, nonatomic) IBOutlet UIButton *q7b;
@property (weak, nonatomic) IBOutlet UIPickerView *q7p;
@property (weak, nonatomic) IBOutlet UIPickerView *q8p;
@property (strong, nonatomic) IBOutlet UIButton *q8b;

@property (strong, nonatomic) IBOutlet UIButton *q8down;
@property (strong, nonatomic) IBOutlet UILabel *q8q;

@end

@implementation view2

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (IBAction)press:(id)sender {
       _q7p.hidden=false;

}
- (IBAction)q8p_press:(id)sender {
    _q8p.hidden=false;
    
}
- (void)viewDidLoad
{
    q7parray = [NSArray arrayWithObjects:NSLocalizedString(@"00 no school completed (skip to Q9)", nil),NSLocalizedString(@"11 1 year primary school (skip to Q9)", nil),NSLocalizedString(@"12 2 years primary school (skip to Q9)", nil),NSLocalizedString(@"13 3 years primary school (skip to Q9)", nil),NSLocalizedString(@"14 4 years primary school (skip to Q9)", nil),NSLocalizedString(@"15 5 years primary school ", nil),NSLocalizedString(@"16 6 years primary school", nil),NSLocalizedString(@"21 1 year lower middle school", nil),NSLocalizedString(@"22 2 year lower middle school", nil),NSLocalizedString(@"23 3 year lower middle school", nil),NSLocalizedString(@"24 1 year upper middle school", nil),NSLocalizedString(@"25 2 year upper middle school", nil),NSLocalizedString(@"26 3 year upper middle school", nil),NSLocalizedString(@"27 1 year technical school", nil),NSLocalizedString(@"28 2 year technical school", nil),NSLocalizedString(@"29 3 year technical school", nil),NSLocalizedString(@"31 1 year college/university", nil),NSLocalizedString(@"32 2 year college/university", nil),NSLocalizedString(@"33 3 year college/university", nil),NSLocalizedString(@"34 4 year college/university", nil),NSLocalizedString(@"35 5 year college/university", nil),NSLocalizedString(@"36 6 year college/university or more", nil),NSLocalizedString(@"-9 unknown", nil),nil];//@"",@"",@"",@"",@"",@"",nil];
    q8parray=[NSArray arrayWithObjects:@"1 Graduate from primary school", @"2 lower middle school degree",@"3 upper middle school degree",@"4 technical or vocational degree",@"5 university or colledge degree",@"6 master's degree or higher",@"9 unknown",nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
}
- (IBAction)q6a_press:(id)sender {
    _q6a.selected=true;
    [_q6a setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q6b.selected=false;
    [_q6b setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    
}

- (IBAction)q6b_press:(id)sender {
    _q6b.selected=true;
    [_q6b setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q6a.selected=false;
    [_q6a setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    
}


-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (pickerView==self.q7p)
    {
        return [q7parray count];
    }
    else
    {
        return [q8parray count];
    }
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    if (pickerView==self.q7p)
    {
        return [q7parray objectAtIndex:row];
    }
    else
    {
       // NSLog(@"sucess into q8p");
        return [q8parray objectAtIndex:row];
    }
}
/*
 -(void)textFieldDidEndEditing:(UITextField *)textField{
 NSInteger row = [_q5p selectedRowInComponent:0];
 self.q5b.titleLabel.text = [q5parray objectAtIndex:row];
 }
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    //NSInteger row = [_q5p selectedRowInComponent:0];
    if (pickerView==self.q7p)
    {
        _q7b.titleLabel.text=[q7parray objectAtIndex:row];
        _q7p.hidden=true;
        [_q7b reloadInputViews];
        if((row>=0)&&(row<5))
        {
            _q8b.hidden=true;
            _q8down.hidden=true;
            _q8q.hidden=true;
            [_q8b reloadInputViews];
            [_q8down reloadInputViews];
            [_q8q reloadInputViews];
          //  NSLog(@"wow");
        }
        else
        {
            _q8b.hidden=false ;
            _q8down.hidden=false;
            [_q8b reloadInputViews];
            [_q8down reloadInputViews];
            _q8q.hidden=false;
            [_q8q reloadInputViews];
        }
    }
    else if (pickerView==self.q8p)
    {
        _q8b.titleLabel.text=[q8parray objectAtIndex:row];
        _q8p.hidden=true;
        [_q8b reloadInputViews];
    }
    
}
- (void)viewDidUnload
{
    [self setQ6a:nil];
    [self setQ6b:nil];
    [self setQ7b:nil];
    [self setQ7p:nil];
    [self setQ8p:nil];
    [self setQ8b:nil];

    [self setQ8down:nil];
    [self setQ8q:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
- (IBAction)Proceed:(id)sender {
    NSString *documentsDirectory = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSError *error;
    
    NSString *plistPath=[documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];

    if(_q6a.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:9];
    }
    else if(_q6b.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:9];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:9];
    }
    [plistDict setObject:[_q7b.titleLabel.text substringWithRange:NSMakeRange(0,2)] atIndexedSubscript:10];
    
    [plistDict setObject:[_q8b.titleLabel.text  substringWithRange:NSMakeRange(0,2)] atIndexedSubscript:11];

    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
