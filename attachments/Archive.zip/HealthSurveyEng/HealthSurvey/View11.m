//
//  view4.m
//  HealthSurvey
//
//  Created by Dax Dawson on 9/30/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "View11.h"

@interface View11 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *hours;
    NSString *tmp;
    NSInteger selectedRowh;
    NSInteger selectedRowmin;
    
}
@property (strong, nonatomic) IBOutlet UIButton *q12a4;
@property (strong, nonatomic) IBOutlet UIButton *q12b4;
@property (strong, nonatomic) IBOutlet UIButton *q12a5;
@property (strong, nonatomic) IBOutlet UIButton *q12b5;
@property (strong, nonatomic) IBOutlet UIButton *q12a6;
@property (strong, nonatomic) IBOutlet UIButton *q12b6;

@property (strong, nonatomic) IBOutlet UIButton *q124b1;
@property (strong, nonatomic) IBOutlet UIButton *q125b1;
@property (strong, nonatomic) IBOutlet UIButton *q126b1;

@property (strong, nonatomic) IBOutlet UIButton *q124b2;
@property (strong, nonatomic) IBOutlet UIButton *q125b2;
@property (strong, nonatomic) IBOutlet UIButton *q126b2;

@property (strong, nonatomic) IBOutlet UIPickerView *q12h;
@property (strong, nonatomic) IBOutlet UIPickerView *q12min;

@end

@implementation View11

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    hours = [NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"12",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26", @"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}


- (IBAction)q10a4_press:(id)sender {
    _q12a4.selected=true;
    [_q12a4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12b4.selected=false;
    [_q12b4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q124b1.hidden=false;
    _q124b2.hidden=false;
}
- (IBAction)q10b4_press:(id)sender {
    _q12b4.selected=true;
    [_q12b4 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12a4.selected=false;
    [_q12a4 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q124b1.hidden=true;
    _q124b2.hidden=true;
}
- (IBAction)q10a5_press:(id)sender {
    _q12a5.selected=true;
    [_q12a5 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12b5.selected=false;
    [_q12b5 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q125b1.hidden=false;
    _q125b2.hidden=false;
}
- (IBAction)q10b5_press:(id)sender {
    _q12b5.selected=true;
    [_q12b5 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12a5.selected=false;
    [_q12a5 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q125b1.hidden=true;
    _q125b2.hidden=true;
}- (IBAction)q10a6_press:(id)sender {
    _q12a6.selected=true;
    [_q12a6 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12b6.selected=false;
    [_q12b6 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q126b1.hidden=false;
    _q126b2.hidden=false;
}
- (IBAction)q10b6_press:(id)sender {
    _q12b6.selected=true;
    [_q12b6 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q12a6.selected=false;
    [_q12a6 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q126b1.hidden=true;
    _q126b2.hidden=true;
}

- (IBAction)q126b2_press:(id)sender {
    
    selectedRowh = [ _q12h  selectedRowInComponent:0];
    selectedRowmin=[_q12min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [sender setTitle:tmp forState:UIControlStateNormal];
    
    
}



-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return [hours count];
    
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    
    return [hours objectAtIndex:row];
    
}

- (IBAction)Proceed:(id)sender {
    NSString *documentsDirectory = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSError *error;
    
    NSString *plistPath=[documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    
    
    // [plistDict setObject:_q9t.text atIndexedSubscript:1:@"WAGE"];
   
    [plistDict setObject:_q124b1.titleLabel.text atIndexedSubscript:38];
    [plistDict setObject:_q125b1.titleLabel.text atIndexedSubscript:40];
    [plistDict setObject:_q126b1.titleLabel.text atIndexedSubscript:42];
  
    [plistDict setObject:_q124b2.titleLabel.text atIndexedSubscript:39];
    [plistDict setObject:_q125b2.titleLabel.text atIndexedSubscript:41];
    [plistDict setObject:_q126b2.titleLabel.text atIndexedSubscript:43];
    
    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
    
    
    
    
    
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
       [self setQ12b4:nil];
    [self setQ12b4:nil];
       [self setQ124b1:nil];
    [self setQ12h:nil];
    [self setQ12min:nil];
    [super viewDidUnload];
}
@end
