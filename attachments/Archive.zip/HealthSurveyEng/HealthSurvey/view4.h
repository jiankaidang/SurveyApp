//
//  view4.h
//  HealthSurvey
//
//  Created by Dax Dawson on 9/30/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface view4 : UIViewController

@end
