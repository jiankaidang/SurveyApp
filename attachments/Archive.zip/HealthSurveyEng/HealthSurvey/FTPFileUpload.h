//
//  FTPFileUpload.h
//  SoftwareInstall
//
//  Created by 朱丹 on 10-12-22.
//  Copyright 2010 朱丹. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CFNetwork/CFFTPStream.h"
//#import "FunctionLib.h"
/*
enum {
	kUploadBufferSize = 8000,
};*/
@protocol FTPFileUploadDelegate;



@interface FTPFileUpload : NSObject {
	id <FTPFileUploadDelegate> delegate;
	NSInteger FLoopCount;   //循环次数
	NSString *					userName;
	NSString *					passWord;
	
	NSString *					serverPath;
	uint64_t					serverSize;
	
	NSString *                  localPath;
	NSString *					fileName;
    uint64_t					localSize;
	
	uint64_t					bufferOffset;
	uint64_t					bufferLimit;
	uint8_t						_buffer[8000];
	
    CFWriteStreamRef			ftpStream;
    
	NSInputStream *fileStream;
	NSString *					strStatus;
	NSString *FUserName;       //FTP账户名
	NSString *FPassWD;         //FTP密码
	NSString *FUploadFile;     //上传文件完整路径
	NSString *FLocalFile;      //需要上传的本地文件
	
	CFRunLoopRef		        runLoop;
	BOOL FIsStart;             //判断是否第一次开始，若在出现一开始内容大小一致时可以重新覆盖
	BOOL FIsSucess;            //判断上传是否已成功
	
}
@property (nonatomic,retain) id <FTPFileUploadDelegate> delegate;

@property (nonatomic, retain) NSString * serverPath;
@property (nonatomic, retain) NSString * userName;
@property (nonatomic, retain) NSString * passWord;
@property (nonatomic, retain) NSString * localPath;
@property (nonatomic, retain) NSString * fileName;
@property (nonatomic, assign) CFWriteStreamRef ftpStream;
@property (nonatomic, retain) NSInputStream * fileStream;
@property (nonatomic, retain) NSString * strStatus;

@property (nonatomic, assign) uint64_t   serverSize;
@property (nonatomic, assign) uint64_t   localSize;
@property (nonatomic, assign) uint64_t   bufferOffset;
@property (nonatomic, assign) uint64_t   bufferLimit;

- (void)stream:(NSStream *)aStream handleEvent:(NSStreamEvent)eventCode;
- (void)stopWithStatus:(NSString *)statusString;
- (void)resume;
- (uint8_t *) buffer;
- (void)resumeRead;
- (void)start;

//初始化FTP信息
-(void)InitFTPInfo : (NSString *)AUserName        //FTP登录账户
		   APassWD : (NSString *)APassWD          //登录密码
	   AUploadPath : (NSString *)AUploadPath      //上传路径
		ALocalFile : (NSString *)ALocalFile;      //需上传文件

@end

@protocol FTPFileUploadDelegate <NSObject>
@optional
//文件上传成功的委托操作
-(void)DidUploadIsFinish;            
//文件上传失败的委托操作
-(void)DidUploadIsFalse : (NSString *)FalseLog;      //失败信息
@end
