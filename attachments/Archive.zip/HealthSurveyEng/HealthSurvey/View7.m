//
//  View7.m
//  HealthSurvey
//
//  Created by Dax Dawson on 10/1/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import "View7.h"

@interface View7 ()<UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *hours;
    NSString *tmp;
    NSInteger selectedRowh;
    NSInteger selectedRowmin;
    
}
@property (strong, nonatomic) IBOutlet UIButton *q13a1;
@property (strong, nonatomic) IBOutlet UIButton *q13b1;
@property (strong, nonatomic) IBOutlet UIButton *q13a2;
@property (strong, nonatomic) IBOutlet UIButton *q13b2;

@property (strong, nonatomic) IBOutlet UIButton *q14a1;
@property (strong, nonatomic) IBOutlet UIButton *q14b1;
@property (strong, nonatomic) IBOutlet UIButton *q14a2;
@property (strong, nonatomic) IBOutlet UIButton *q14b2;
@property (strong, nonatomic) IBOutlet UIButton *q14a3;
@property (strong, nonatomic) IBOutlet UIButton *q14b3;

@property (strong, nonatomic) IBOutlet UIButton *q131b2;
@property (strong, nonatomic) IBOutlet UIButton *q132b2;
@property (strong, nonatomic) IBOutlet UIButton *q131b1;
@property (strong, nonatomic) IBOutlet UIButton *q132b1;
@property (strong, nonatomic) IBOutlet UIPickerView *q13h;
@property (strong, nonatomic) IBOutlet UIPickerView *q13min;

@end

@implementation View7

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    hours = [NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"12",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26", @"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (IBAction)q13a1_press:(id)sender {
    _q13a1.selected=true;
    [_q13a1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q13b1.selected=false;
    [_q13b1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q131b1.hidden=false;
    _q131b2.hidden=false;
    
}
- (IBAction)q13b1_press:(id)sender {
    _q13b1.selected=true;
    [_q13b1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q13a1.selected=false;
    [_q13a1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q131b1.hidden=true;
    _q131b2.hidden=true;
    
}
- (IBAction)q13a2_press:(id)sender {
    _q13a2.selected=true;
    [_q13a2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q13b2.selected=false;
    [_q13b2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q132b1.hidden=false;
    _q132b2.hidden=false;
    
}
- (IBAction)q13b2_press:(id)sender {
    _q13b2.selected=true;
    [_q13b2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q13a2.selected=false;
    [_q13a2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    _q132b1.hidden=true;
    _q132b2.hidden=true;
}

- (IBAction)q136b2_press:(id)sender {
    
    selectedRowh = [ _q13h  selectedRowInComponent:0];
    selectedRowmin=[_q13min selectedRowInComponent:0];
    tmp=[[[hours objectAtIndex:selectedRowh] stringByAppendingString:@":"]stringByAppendingString:[hours objectAtIndex:selectedRowmin]];
    
    [sender setTitle:tmp forState:UIControlStateNormal];
    
    
}
- (IBAction)q14a1_press:(id)sender {
    _q14a1.selected=true;
    [_q14a1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q14b1.selected=false;
    [_q14b1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    //_q141b1.hidden=false;
    //_q141b2.hidden=false;
    
}
- (IBAction)q14b1_press:(id)sender {
    _q14b1.selected=true;
    [_q14b1 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q14a1.selected=false;
    [_q14a1 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    //_q131b1.hidden=true;
    //_q131b2.hidden=true;
    
}
- (IBAction)q14a2_press:(id)sender {
    _q14a2.selected=true;
    [_q14a2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q14b2.selected=false;
    [_q14b2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    //_q142b1.hidden=false;
    //_q142b2.hidden=false;
    
}
- (IBAction)q14b2_press:(id)sender {
    _q14b2.selected=true;
    [_q14b2 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q14a2.selected=false;
    [_q14a2 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    //_q142b1.hidden=true;
    //_q132b2.hidden=true;
}
- (IBAction)q14a3_press:(id)sender {
    _q14a3.selected=true;
    [_q14a3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q14b3.selected=false;
    [_q14b3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    //_q142b1.hidden=false;
    //_q142b2.hidden=false;
    
}
- (IBAction)q14b3_press:(id)sender {
    _q14b3.selected=true;
    [_q14b3 setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    _q14a3.selected=false;
    [_q14a3 setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    //_q142b1.hidden=true;
    //_q132b2.hidden=true;
}




-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return [hours count];
    
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    
    return [hours objectAtIndex:row];
    
}

- (IBAction)Proceed:(id)sender {
    NSString *documentsDirectory = [NSHomeDirectory()stringByAppendingPathComponent:@"Documents"];
    NSError *error;
    
    NSString *plistPath=[documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@",@"stack.plist"]];
    NSMutableArray *plistDict=[[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    
    
    // [plistDict setObject:_q9t.text atIndexedSubscript:1:@"WAGE"];
    
    [plistDict setObject:_q131b1.titleLabel.text atIndexedSubscript:44];
    [plistDict setObject:_q132b1.titleLabel.text atIndexedSubscript:46];
       [plistDict setObject:_q131b2.titleLabel.text atIndexedSubscript:45];
    [plistDict setObject:_q132b2.titleLabel.text atIndexedSubscript:47];
    if(_q14a1.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:48];
    }
    else if(_q14b1.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:48];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:48];
    }
    if(_q14a2.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:49];
    }
    else if(_q14b2.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:49];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:49];
    }
    if(_q14a3.selected==true)
    {
        [plistDict setObject:@"1" atIndexedSubscript:50];
    }
    else if(_q14b3.selected==true)
    {
        [plistDict setObject:@"2" atIndexedSubscript:50];
    }
    else
    {
        [plistDict setObject:@"0" atIndexedSubscript:50];
    }
    
    [plistDict writeToFile:plistPath atomically:YES];
    NSLog(@"%@",plistDict);
    
    
    
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setQ14a1:nil];
    [self setQ14b1:nil];
    [self setQ14a2:nil];
    [self setQ14b2:nil];
    [self setQ14a3:nil];
    [self setQ14b3:nil];
    [super viewDidUnload];
}
@end
