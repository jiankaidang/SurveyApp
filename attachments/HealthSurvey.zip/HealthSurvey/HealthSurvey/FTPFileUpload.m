//
//  FTPFileUpload.m
//  SoftwareInstall
//
//  Created by 朱丹 on 10-12-22.
//  Copyright 2010 朱丹. All rights reserved.
//

#import "FTPFileUpload.h"

NSInteger FFalseTypeCode;    //错误类型代码
							 //1:本地文件与上传文件尺寸不匹配
							 //2:文件读取错误
							 //3:网络写错误
							 //4:打开流错误
							 //5:本地文件读取错误
const	
	NSInteger kUploadBufferSize = 8000;
	NSString *FinishTag = @"Finish";

void theWriteCallBack (CFWriteStreamRef stream,
					   CFStreamEventType eventType,
					   void *clientCallBackInfo) {
	FTPFileUpload * ud = (FTPFileUpload*)clientCallBackInfo;

	switch (eventType) {
        case kCFStreamEventOpenCompleted: {
            ud.strStatus = @"Opened connection";
			NSLog(@"connection opened for %@", ud.serverPath);
			BOOL success = (ud.serverSize > 0);
			
			
			// Open a stream for the file we're going to receive into.
			if (ud.serverSize < ud.localSize){
				ud.fileStream = [NSInputStream inputStreamWithFileAtPath: ud.localPath];
				[ud.fileStream open];
				if (success){
					uint64_t lsize = ud.serverSize;
					[ud.fileStream setProperty:[NSNumber numberWithInt:lsize] forKey:NSStreamFileCurrentOffsetKey];
					ud.strStatus = @"server file existing, appending the data";
				} else {
					ud.strStatus = @"uploading the file from the starting point";
				}
				assert(ud.fileStream != nil);
			
			} else {
				ud.strStatus = @"local file size <= server file, aborting...";
				if (ud.serverSize > ud.localSize) {
					FFalseTypeCode = 1;
					[ud stopWithStatus:@"本地文件与上传文件尺寸不匹配！"
					 //@"file size not match!"
					 ];
				}
				else {
					[ud stopWithStatus:FinishTag
					 //@"file size not match!"
					 ];
				}

				
			}
        } break;
        case kCFStreamEventCanAcceptBytes: {
			// If we don't have any data buffered, go read the next chunk of data.
            if (ud.bufferOffset == ud.bufferLimit) {
				uint8_t * buffer = ud.buffer;
                NSInteger bytesRead = [ud.fileStream read:buffer maxLength:kUploadBufferSize];
                if (bytesRead == -1) {
					FFalseTypeCode = 5;
                    [ud stopWithStatus:@"本地文件读取错误！"
					 //@"local file read error!"
					 ];
                } else if (bytesRead == 0) {
					[ud.fileStream close];
					ud.fileStream = NULL;
                    [ud stopWithStatus:FinishTag];
                } else {
                    ud.bufferOffset = 0;
                    ud.bufferLimit  = bytesRead;
                }
            }
            
            // If we're not out of data completely, send the next chunk.
            if (ud.bufferOffset != ud.bufferLimit) {
                NSInteger   bytesWritten;
				uint8_t		* buffer = ud.buffer;
				bytesWritten = CFWriteStreamWrite(ud.ftpStream, &(buffer[ud.bufferOffset]), ud.bufferLimit - ud.bufferOffset);
                assert(bytesWritten != 0);
                if (bytesWritten == -1) {
					FFalseTypeCode = 3;
                    [ud stopWithStatus:@"网络写错误！"
					 //@"Network write error"
					 ];
                } else {
                    ud.bufferOffset += bytesWritten;
					ud.serverSize += bytesWritten;
                }
            }
			ud.strStatus = [NSString stringWithFormat:@"sending %llu/%llu", ud.serverSize, ud.localSize];
        } break;
        case kCFStreamEventErrorOccurred: {
			CFErrorRef error = CFWriteStreamCopyError(ud.ftpStream);
			CFStringRef  desc = CFErrorCopyDescription(error);
			CFStringRef reason = CFErrorCopyFailureReason(error);
			CFStringRef suggest= CFErrorCopyRecoverySuggestion(error);
			NSLog(@"write stream error %@: reason:%@, suggest:%2", 
				  (NSString*)desc,
				  (NSString*)reason,
				  (NSString*)suggest);
			
			FFalseTypeCode = 4;
            [ud stopWithStatus:@"打开流错误！"
			 //@"Stream open error"
			 ];
			break;
        } break;
        default: {
            assert(NO);
        } break;
    }
} 

@implementation FTPFileUpload

@synthesize delegate;
@synthesize serverPath;
@synthesize userName;
@synthesize passWord;
@synthesize localPath;
@synthesize fileName;
@synthesize ftpStream;
@synthesize fileStream;
@synthesize strStatus;
@synthesize serverSize;
@synthesize localSize;
@synthesize bufferOffset;
@synthesize bufferLimit;

- (uint8_t *) buffer {
	return self->_buffer;
}

- (void)stream:(NSStream *)aStream handleEvent:(NSStreamEvent)eventCode
// An NSStream delegate callback that's called when events happen on our 
// network stream.
{
    switch (eventCode) {
        case NSStreamEventOpenCompleted: {
			if (aStream == self.fileStream) {
				// get the server size from ftp
				self.serverSize = 0;
				// check server file's size
				NSNumber * cfSize = [self.fileStream propertyForKey:(id)kCFStreamPropertyFTPResourceSize];
				if (cfSize != nil) {
					uint64_t size = [cfSize unsignedLongLongValue];
					self.strStatus = [NSString stringWithFormat:@"Existing server size is %llu", size];
					self.serverSize = size;
				} else {
					self.serverSize = 0;
				}
				
				if (self.serverSize == self.localSize) {   //服务器文件与本地文件大小一致
					if (FIsStart == YES) {
						self.serverSize = 0;
						[self.fileStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
						self.fileStream.delegate = nil;
						[self.fileStream close];
						self.fileStream = nil;
						
						// OK, let's start uploading now.
						[self resume];
						FIsStart = NO;
					}
					else {
						[self stopWithStatus:FinishTag
						 ];
					}

					
				}
				else {
					self.serverSize = 0;
					[self.fileStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
					self.fileStream.delegate = nil;
					[self.fileStream close];
					self.fileStream = nil;
					
					// OK, let's start uploading now.
					[self resume];
				}

				
				return;
			}
			
			self.strStatus = @"Opened connection";
			NSLog(@"connection opened for %@", self.serverPath);
			
			// Open a stream for the file we're going to receive into.
			if (self.serverSize < self.localSize){
				self.fileStream = [NSInputStream inputStreamWithFileAtPath: self.localPath];
				[self.fileStream open];
				assert(self.fileStream != nil);
				uint64_t lsize = self.serverSize;
				[self.fileStream setProperty:[NSNumber numberWithUnsignedLongLong:lsize] forKey:NSStreamFileCurrentOffsetKey];
				self.strStatus = [NSString stringWithFormat:@"write to file from %llu", lsize];
				
			} else {
				FFalseTypeCode = 1;
				self.strStatus = @"local file size <= server file, aborting...";
				[self stopWithStatus:@"本地文件与上传文件尺寸不匹配！"
				 //@"file size not match!"
				 ];
			}
			
			
        } break;
        case NSStreamEventHasBytesAvailable: {
            assert(NO);     // should never happen for the output stream
        } break;
        case NSStreamEventHasSpaceAvailable: {
			if (aStream == self.fileStream)
				return;
            uint8_t  * buf = self.buffer;
            // If we don't have any data buffered, go read the next chunk of data.
            
            if (self.bufferOffset == self.bufferLimit) {
                NSInteger   bytesRead;
                
                bytesRead = [self.fileStream read:buf maxLength:kUploadBufferSize];
                
                if (bytesRead == -1) {
					FFalseTypeCode = 2;
                    [self stopWithStatus:@"文件读取错误！"
					 //@"File read error"
					 ];
                } else if (bytesRead == 0) {
                    [self stopWithStatus:FinishTag];
					return;
                } else {
                    self.bufferOffset = 0;
                    self.bufferLimit  = bytesRead;
                }
            }
            
            // If we're not out of data completely, send the next chunk.
            if (self.bufferOffset != self.bufferLimit) {
                NSInteger   bytesWritten;
				
                bytesWritten = [self.ftpStream write:&buf[self.bufferOffset] maxLength:self.bufferLimit - self.bufferOffset];
                assert(bytesWritten != 0);
                if (bytesWritten == -1) {
					FFalseTypeCode = 3;
                    [self stopWithStatus:@"网络写错误！"
					 //@"Network write error"
					 ];
					return;
                } else {
                    self.bufferOffset += bytesWritten;
					self.serverSize += bytesWritten;
                }
            }
			self.strStatus = [NSString stringWithFormat:@"sending %llu/%llu", self.serverSize, self.localSize];
        } break;
        case NSStreamEventErrorOccurred: {
			FFalseTypeCode = 4;
			[self stopWithStatus:@"打开流错误！"
			 //@"Stream open error"
			 ];
			if (aStream == self.fileStream)
				return;
			[self stopWithStatus:@"打开流错误！"
			 //@"Stream open error"
			 ];
            
        } break;
        case NSStreamEventEndEncountered: {
			if (aStream == self.fileStream)
				return;
			[self.delegate DidUploadIsFinish];
            [self stopWithStatus:nil
			 //@"Upload Completed."
			 ];
        } break;
        default: {
            assert(NO);
        } break;
    }
}


- (void)stopWithStatus:(NSString *)statusString
{
	//self = [super init];
	NSLog(@"statusString = %@",statusString);
	CFRunLoopStop(runLoop);
	if (self.ftpStream != NULL) {
		CFWriteStreamUnscheduleFromRunLoop(self.ftpStream, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode);
		CFWriteStreamClose(self.ftpStream);
		CFRelease(self.ftpStream);
		self.ftpStream = NULL;
	}
	
	if ((FFalseTypeCode == 1) || (FFalseTypeCode == 4) || (FFalseTypeCode == 5)) {
		FLoopCount--;
		if (FLoopCount > 0) {
			FFalseTypeCode = 0;
			CFRunLoopStop(runLoop);
			[self start];
		}
		else {
			if (FIsSucess == NO) {
				[self.delegate DidUploadIsFalse:statusString];
			}
		}

		
	}
	else {
		if (self.fileStream != NULL) {
			[self.fileStream close];
			self.fileStream = NULL;
		}
		
		if ([statusString compare:FinishTag] == NSOrderedSame) {
			CFRunLoopStop(runLoop);
			FIsSucess = YES;
			[self.delegate DidUploadIsFinish];
		}
		else {
			
			if (statusString != nil) {
				self.strStatus = statusString;			
			} else {
				//[self.delegate DidUploadIsFinish];
				self.strStatus = @"Uploading Completed.";
			}
			if (FIsSucess == NO) {
				[self.delegate DidUploadIsFalse:statusString];
			}
			
		}
		
	}

	
	

    
	
	
	
}

- (void)resume {
	// First get and check the URL.
    NSURL * url = [[NSURL alloc] initWithString:FUploadFile];
    BOOL success = (url != nil);
	
    if ( ! success) {
        self.strStatus = @"Invalid URL";
    } else {
		// Open a CFFTPStream for the URL.
        self.ftpStream = CFWriteStreamCreateWithFTPURL(NULL, (CFURLRef) url);
		
		if (self.userName != 0) {
            success = CFWriteStreamSetProperty(self.ftpStream, kCFStreamPropertyFTPUserName, self.userName);
            assert(success);
            success = CFWriteStreamSetProperty(self.ftpStream, kCFStreamPropertyFTPPassword, self.passWord);
            assert(success);
        }
        success = CFWriteStreamSetProperty(self.ftpStream, kCFStreamPropertyFTPFileTransferOffset, [NSNumber numberWithUnsignedLongLong: self.serverSize]);
		success = CFWriteStreamSetProperty(self.ftpStream, kCFStreamPropertyAppendToFile, kCFBooleanTrue);
		
		CFStreamClientContext context = {
			0,  (void*)self, NULL, NULL, NULL
		};
		CFOptionFlags flag = kCFStreamEventOpenCompleted | kCFStreamEventCanAcceptBytes | kCFStreamEventErrorOccurred;
		CFWriteStreamSetClient(self.ftpStream, flag, theWriteCallBack, &context);
		
		CFWriteStreamScheduleWithRunLoop (self.ftpStream, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode);
		CFWriteStreamOpen(self.ftpStream);
    }	
}

- (void)start {
	//[NSThread detachNewThreadSelector:@selector(threadMain:) toTarget:self withObject:nil];
	FIsSucess = NO;
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	runLoop = CFRunLoopGetCurrent();
	void * p = runLoop;
	NSLog(@" the current thread's loop is %p", p);
	
	[self resumeRead];	
	// [self resume];
	// CFRunLoopRunInMode(kCFRunLoopDefaultMode, 1000, NO);
	CFRunLoopRun();
	
	NSLog(@"thread exiting...");
	[pool release];
}

- (void)threadMain:(id)arg {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	runLoop = CFRunLoopGetCurrent();
	void * p = runLoop;
	NSLog(@" the current thread's loop is %p", p);
	
	[self resumeRead];	
	// [self resume];
	// CFRunLoopRunInMode(kCFRunLoopDefaultMode, 1000, NO);
	CFRunLoopRun();
	
	NSLog(@"thread exiting...");
	[pool release];
	
}

- (void)resumeRead {
	// First get and check the URL.
    NSURL * url = [[NSURL alloc] initWithString:FUploadFile];
    BOOL success = (url != nil);
	self.serverSize = 0;
	
    if ( ! success) {
        self.strStatus = @"Invalid URL";
    } else {
		// Open a CFFTPStream for the URL.
        CFReadStreamRef fs = CFReadStreamCreateWithFTPURL(NULL, (CFURLRef) url);
        assert(fs != NULL);
		self.fileStream = (NSInputStream *) fs;
        
		if (self.userName != 0) {
			success = [self.fileStream setProperty:self.userName forKey:(id)kCFStreamPropertyFTPUserName];
			assert(success);
			success = [self.fileStream setProperty:self.passWord forKey:(id)kCFStreamPropertyFTPPassword];
			assert(success);
		}
		
		success = [self.fileStream setProperty:(id)kCFBooleanTrue forKey:(id)kCFStreamPropertyFTPFetchResourceInfo];
		
        self.fileStream.delegate = self;
        [self.fileStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        [self.fileStream open];
		
		CFRelease(fs);
    }	
}
/*

-(void)InitFTPInfo : (NSString *)AUserName
		   APassWD : (NSString *)APassWD
	   AUploadPath : (NSString *)AUploadPath
		ALocalFile : (NSString *)ALocalFile {
	//self = [super init];
	FIsStart = YES;
	FFalseTypeCode = 0;
	FLoopCount = 2;
	FunctionLib *ALib = [[FunctionLib alloc] init];
	userName = AUserName;
	passWord = APassWD;
	FUploadFile = [[NSString alloc] initWithFormat:@"%@/%@",AUploadPath,[ALib GetFileName:ALocalFile]];
	FLocalFile = ALocalFile;//[ALib ReplaceText:ALocalFile TargetData:@" " ReplaceData:@"\\ "];
	
	NSLog(@"%@",FLocalFile);
	self.serverPath = FUploadFile;
	self.localPath = FLocalFile;
	NSLog(@"%@",self.localPath);
	self.localSize = [ALib getFileSize: ALocalFile];
	[ALib release];/*
	if ([self CheckServerAndLocalFileIsSame] == YES) {
		NSLog(@"yes");
	}
	else {
		NSLog(@"no");
	}
//*/

- (void)dealloc {
	[userName release];
	[passWord release];

	[serverPath release];
	[localPath release];
	[fileName release];
	
	[strStatus release];
	[FUploadFile release];
	
	[super dealloc];
}

@end
