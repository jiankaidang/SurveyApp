//
//  AppDelegate.h
//  HealthSurvey
//
//  Created by Dax Dawson on 9/23/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
