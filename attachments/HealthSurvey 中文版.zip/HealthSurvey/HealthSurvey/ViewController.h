//
//  ViewController.h
//  HealthSurvey
//
//  Created by Dax Dawson on 9/23/12.
//  Copyright (c) 2012 Peigen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *q2a;
@property (strong, nonatomic) IBOutlet UIButton *q2b;
@property (strong, nonatomic) IBOutlet UIButton *q4a;
@property (strong, nonatomic) IBOutlet UIButton *q4b;



@end
